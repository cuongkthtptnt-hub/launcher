package com.mrcuong.launcher

import android.annotation.SuppressLint
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.IntentFilter
import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import android.util.LruCache
import android.util.Log
import android.util.Xml
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import kotlin.math.abs

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var web: WebView
    private lateinit var sm: SensorManager
    private var sat = 24f
    private var sab = 16f
    private var lastSend = 0L
    private var lg = 999.0
    private var lb = 999.0
    private val iconCache = LruCache<String, ByteArray>(256)
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var widgetMgr: AppWidgetManager
    private lateinit var widgetLayer: FrameLayout
    private val widgetViews = HashMap<Int, AppWidgetHostView>()
    private var packPkg = ""
    private var packMap: Map<String, String> = emptyMap()

    private val pickWidgetLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val id = r.data?.getIntExtra("id", -1) ?: -1
        val ok = r.resultCode == Activity.RESULT_OK && id >= 0
        js("window.__widgetAdded&&__widgetAdded(${if (ok) id else -1})")
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveWallpaper(uri)
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            // Bỏ qua sự kiện gỡ tạm thời khi ứng dụng đang được cập nhật
            if (i != null && i.action == Intent.ACTION_PACKAGE_REMOVED && i.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
            js("window.__refresh&&__refresh()")
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#0A0F2E"))
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
        }
        widgetMgr = AppWidgetManager.getInstance(this)
        widgetHost = AppWidgetHost(applicationContext, WidgetsActivity.HOST_ID)
        widgetLayer = FrameLayout(this)
        val root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(widgetLayer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        packPkg = getSharedPreferences("meta", Context.MODE_PRIVATE).getString("iconpack", "") ?: ""
        packMap = if (packPkg.isEmpty()) emptyMap() else loadPackMap(packPkg)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            textZoom = 100          // không bị phóng chữ theo cỡ chữ hệ thống
            setSupportZoom(false)
        }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val p = request.url.path ?: ""
                if (p == "/wall/custom.jpg") return wallpaper()
                if (p.startsWith("/icon/")) return icon(p.removePrefix("/icon/").removeSuffix(".png"), request.url.getQueryParameter("c") ?: "")
                return loader.shouldInterceptRequest(request.url)
            }
            override fun onPageFinished(view: WebView?, url: String?) { pushInsets() }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        ViewCompat.setOnApplyWindowInsetsListener(web) { _, ins ->
            val s = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val d = resources.displayMetrics.density
            sat = s.top / d
            sab = s.bottom / d
            pushInsets()
            ins
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { js("window.__back&&__back()") }
        })

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onStart() {
        super.onStart()
        try { widgetHost.startListening() } catch (e: Exception) { Log.w("Launcher", "widget host lỗi", e) }
    }

    override fun onStop() {
        super.onStop()
        try { widgetHost.stopListening() } catch (e: Exception) { Log.w("Launcher", "widget host lỗi", e) }
    }

    override fun onResume() {
        super.onResume()
        sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        web.onResume()
        js("window.__resume&&__resume()")
    }

    override fun onPause() {
        super.onPause()
        sm.unregisterListener(this)
        web.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        js("window.__home&&__home()")
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        web.destroy()
        super.onDestroy()
    }

    override fun onSensorChanged(e: SensorEvent) {
        val now = System.currentTimeMillis()
        if (now - lastSend < 50) return
        val r = FloatArray(9)
        val o = FloatArray(3)
        SensorManager.getRotationMatrixFromVector(r, e.values)
        SensorManager.getOrientation(r, o)
        val beta = Math.toDegrees(-o[1].toDouble())
        val gamma = Math.toDegrees(o[2].toDouble())
        if (abs(gamma - lg) < 0.6 && abs(beta - lb) < 0.6) return   // bỏ qua rung nhẹ
        lastSend = now
        lg = gamma
        lb = beta
        js("window.__tilt&&__tilt(${gamma / 28},${(beta - 60) / 28})")
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    private fun js(code: String) { web.post { web.evaluateJavascript(code, null) } }

    private fun pushInsets() {
        js("document.documentElement.style.setProperty('--sat','${sat}px');" +
           "document.documentElement.style.setProperty('--sab','${sab}px')")
    }

    private fun wallpaper(): WebResourceResponse? {
        val f = File(filesDir, "wall.jpg")
        if (!f.exists()) return null
        return try {
            WebResourceResponse("image/jpeg", null, FileInputStream(f)).apply {
                responseHeaders = mapOf("Cache-Control" to "no-store")
            }
        } catch (e: Exception) { null }
    }

    /** Giải mã ảnh người dùng chọn (thu nhỏ, xoay theo EXIF) rồi lưu vào bộ nhớ riêng của launcher. */
    private fun saveWallpaper(uri: Uri) {
        Thread {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 2200 || bounds.outHeight / sample > 2200) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: throw IllegalStateException("Không giải mã được ảnh")
                val orientation = try {
                    contentResolver.openInputStream(uri)?.use {
                        ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                    } ?: ExifInterface.ORIENTATION_NORMAL
                } catch (e: Exception) { ExifInterface.ORIENTATION_NORMAL }
                val deg = when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
                if (deg != 0f) {
                    val m = Matrix()
                    m.postRotate(deg)
                    bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                }
                File(filesDir, "wall.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                runOnUiThread { js("window.__wallpaper&&__wallpaper()") }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Không đặt được hình nền", Toast.LENGTH_SHORT).show() }
            }
        }.start()
    }

    private fun icon(pkg: String, cls: String): WebResourceResponse? = try {
        val key = "$packPkg|$pkg|$cls"
        val bytes = iconCache.get(key) ?: run {
            val bo = ByteArrayOutputStream()
            iconBitmap(pkg, cls).compress(Bitmap.CompressFormat.PNG, 100, bo)
            bo.toByteArray().also { iconCache.put(key, it) }
        }
        WebResourceResponse("image/png", null, ByteArrayInputStream(bytes))
    } catch (e: Exception) { null }

    /** Icon từ icon pack đang chọn (theo appfilter) nếu có, ngược lại dùng icon gốc của ứng dụng. */
    private fun iconBitmap(pkg: String, cls: String): Bitmap {
        val name = if (packPkg.isNotEmpty() && cls.isNotEmpty()) packMap["$pkg/$cls"] else null
        if (name != null) {
            try {
                val res = packageManager.getResourcesForApplication(packPkg)
                val id = res.getIdentifier(name, "drawable", packPkg)
                if (id != 0) {
                    val d = ResourcesCompat.getDrawable(res, id, null)
                    if (d != null) return d.toBitmap(96, 96)
                }
            } catch (e: Exception) { Log.w("Launcher", "icon pack lỗi: $name", e) }
        }
        return packageManager.getApplicationIcon(pkg).toBitmap(72, 72)
    }

    /** Đọc appfilter.xml (chuẩn ADW/Nova) của icon pack: ánh xạ "gói/lớp" -> tên drawable. */
    private fun loadPackMap(pack: String): Map<String, String> {
        val map = HashMap<String, String>()
        try {
            val res = packageManager.getResourcesForApplication(pack)
            val id = res.getIdentifier("appfilter", "xml", pack)
            val parser: XmlPullParser = if (id != 0) {
                res.getXml(id)
            } else {
                val p = Xml.newPullParser()
                p.setInput(createPackageContext(pack, 0).assets.open("appfilter.xml"), null)
                p
            }
            val re = Regex("ComponentInfo\\{([^/]+)/([^}]+)\\}")
            var ev = parser.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                    val comp = parser.getAttributeValue(null, "component")
                    val dr = parser.getAttributeValue(null, "drawable")
                    if (comp != null && dr != null) {
                        val m = re.find(comp)
                        if (m != null) {
                            var cls = m.groupValues[2]
                            if (cls.startsWith(".")) cls = m.groupValues[1] + cls
                            map[m.groupValues[1] + "/" + cls] = dr
                        }
                    }
                }
                ev = parser.next()
            }
        } catch (e: Exception) {
            Log.w("Launcher", "Không đọc được icon pack $pack", e)
        }
        return map
    }

    private fun hostView(id: Int): AppWidgetHostView? {
        val cached = widgetViews[id]
        if (cached != null) return cached
        val info = try { widgetMgr.getAppWidgetInfo(id) } catch (e: Exception) { null }
        if (info == null) return null
        val hv = try { widgetHost.createView(applicationContext, id, info) } catch (e: Exception) { null }
        if (hv == null) return null
        hv.setOnLongClickListener {
            js("window.__widgetMenu&&__widgetMenu($id)")
            true
        }
        widgetViews[id] = hv
        widgetLayer.addView(hv)
        return hv
    }

    /** Nhận danh sách widget trên màn hình chính từ giao diện: {id,x,y,w,h,v} (đơn vị CSS px = dp). */
    private fun applyWidgets(json: String) {
        val arr = try { JSONArray(json) } catch (e: Exception) { return }
        val d = resources.displayMetrics.density
        val keep = HashSet<Int>()
        for (k in 0 until arr.length()) {
            val o = arr.optJSONObject(k) ?: continue
            val id = o.optInt("id", -1)
            if (id < 0) continue
            keep.add(id)
            val hv = hostView(id)
            if (hv == null) {
                js("window.__widgetGone&&__widgetGone($id)")
                continue
            }
            val w = (o.optDouble("w", 0.0) * d).toInt()
            val h = (o.optDouble("h", 0.0) * d).toInt()
            val lp = FrameLayout.LayoutParams(w, h)
            lp.leftMargin = (o.optDouble("x", 0.0) * d).toInt()
            lp.topMargin = (o.optDouble("y", 0.0) * d).toInt()
            hv.layoutParams = lp
            val show = o.optInt("v", 0) == 1 && w > 0 && h > 0
            hv.visibility = if (show) View.VISIBLE else View.GONE
            if (show) {
                try {
                    hv.updateAppWidgetSize(Bundle(), (w / d).toInt(), (h / d).toInt(), (w / d).toInt(), (h / d).toInt())
                } catch (e: Exception) { Log.w("Launcher", "updateAppWidgetSize lỗi", e) }
            }
        }
        for (id in widgetViews.keys.toList()) {
            if (id !in keep) widgetViews.remove(id)?.let { widgetLayer.removeView(it) }
        }
    }

    private fun start(i: Intent) {
        runOnUiThread {
            try {
                val opt = ActivityOptions.makeCustomAnimation(this, R.anim.glass_in, R.anim.glass_out)
                startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), opt.toBundle())
            } catch (_: Exception) {
                js("window.__resume&&__resume()")
            }
        }
    }

    private fun cat(c: String) = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, c)

    inner class Bridge {
        @JavascriptInterface
        fun apps(): String {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { it to it.loadLabel(pm).toString() }
                .sortedBy { it.second.lowercase() }
                .forEach { (ri, label) ->
                    val pkg = ri.activityInfo.packageName
                    val installed = try { pm.getPackageInfo(pkg, 0).firstInstallTime } catch (e: Exception) { 0L }
                    val isSystem = (ri.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    arr.put(JSONObject()
                        .put("n", label)
                        .put("p", pkg)
                        .put("c", ri.activityInfo.name)
                        .put("i", "/icon/$pkg.png?c=${Uri.encode(ri.activityInfo.name)}&v=${Uri.encode(packPkg)}")
                        .put("t", installed)
                        .put("s", isSystem))
                }
            return arr.toString()
        }

        /** 0: máy dưới Android 9, 1: chưa bật dịch vụ khóa, 2: sẵn sàng. */
        @JavascriptInterface
        fun lockStatus(): Int = when {
            Build.VERSION.SDK_INT < Build.VERSION_CODES.P -> 0
            LockService.instance != null -> 2
            else -> 1
        }

        @JavascriptInterface
        fun lockScreen(): Boolean {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return false
            val svc = LockService.instance ?: return false
            return try { svc.lockNow() } catch (e: Exception) { Log.w("Launcher", "khóa màn hình lỗi", e); false }
        }

        @JavascriptInterface
        fun openAccessibility() { start(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        @JavascriptInterface
        fun addWidget() {
            runOnUiThread {
                try {
                    pickWidgetLauncher.launch(Intent(this@MainActivity, WidgetsActivity::class.java).putExtra("pick", true))
                } catch (e: Exception) {
                    Log.w("Launcher", "Không mở được bộ chọn widget", e)
                    js("window.__widgetAdded&&__widgetAdded(-1)")
                }
            }
        }

        @JavascriptInterface
        fun setWidgets(json: String) { runOnUiThread { applyWidgets(json) } }

        @JavascriptInterface
        fun deleteWidget(id: Int) {
            runOnUiThread {
                try { widgetHost.deleteAppWidgetId(id) } catch (e: Exception) { Log.w("Launcher", "xóa widget lỗi", e) }
                widgetViews.remove(id)?.let { widgetLayer.removeView(it) }
            }
        }

        @JavascriptInterface
        fun hasWidget(id: Int): Boolean = try { widgetMgr.getAppWidgetInfo(id) != null } catch (e: Exception) { false }

        @JavascriptInterface
        fun keepWidgets(json: String) {
            runOnUiThread {
                try {
                    val keep = HashSet<Int>()
                    val arr = JSONArray(json)
                    for (i in 0 until arr.length()) keep.add(arr.getInt(i))
                    val sp = getSharedPreferences("hostwidgets", Context.MODE_PRIVATE)
                    val old = (sp.getString("ids", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
                    for (id in old) {
                        if (id !in keep) {
                            try { widgetHost.deleteAppWidgetId(id) } catch (e: Exception) { Log.w("Launcher", "xóa widget cũ lỗi", e) }
                        }
                    }
                    sp.edit().putString("ids", keep.joinToString(",")).apply()
                } catch (e: Exception) { Log.w("Launcher", "keepWidgets lỗi", e) }
            }
        }

        @JavascriptInterface
        fun iconPacks(): String {
            val seen = HashSet<String>()
            val arr = JSONArray()
            for (action in listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.anddoes.launcher.THEME")) {
                try {
                    for (ri in packageManager.queryIntentActivities(Intent(action), 0)) {
                        val p = ri.activityInfo.packageName
                        if (p != packageName && seen.add(p)) {
                            arr.put(JSONObject().put("p", p).put("n", ri.loadLabel(packageManager).toString()))
                        }
                    }
                } catch (e: Exception) { Log.w("Launcher", "đọc icon pack lỗi", e) }
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun getIconPack(): String = packPkg

        @JavascriptInterface
        fun setIconPack(pkg: String) {
            runOnUiThread {
                packPkg = pkg
                packMap = if (pkg.isEmpty()) emptyMap() else loadPackMap(pkg)
                iconCache.evictAll()
                getSharedPreferences("meta", Context.MODE_PRIVATE).edit().putString("iconpack", pkg).apply()
                js("window.__refresh&&__refresh()")
            }
        }

        @JavascriptInterface
        fun pickWallpaper() { runOnUiThread { pickImage.launch("image/*") } }

        @JavascriptInterface
        fun hasWallpaper(): Boolean = File(filesDir, "wall.jpg").exists()

        @JavascriptInterface
        fun resetWallpaper() {
            File(filesDir, "wall.jpg").delete()
            js("window.__wallpaper&&__wallpaper()")
        }

        @JavascriptInterface
        fun openWidgets() {
            runOnUiThread { startActivity(Intent(this@MainActivity, WidgetsActivity::class.java)) }
        }

        @JavascriptInterface
        fun getPrefs(): String = getSharedPreferences("launcher", Context.MODE_PRIVATE).getString("data", "") ?: ""

        @JavascriptInterface
        fun setPrefs(json: String) {
            if (json.length < 2_000_000)
                getSharedPreferences("launcher", Context.MODE_PRIVATE).edit().putString("data", json).apply()
        }

        @JavascriptInterface
        fun info(pkg: String) {
            start(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
        }

        @JavascriptInterface
        fun uninstall(pkg: String) {
            start(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
        }

        @JavascriptInterface
        fun notifications() {
            runOnUiThread {
                try {
                    Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel")
                        .invoke(getSystemService("statusbar"))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Thiết bị không cho phép mở thanh thông báo", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun share(text: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(i, "Chia sẻ cấu hình"))
            }
        }

        @JavascriptInterface
        fun copy(text: String) {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("launcher", text))
            }
        }

        @JavascriptInterface
        fun chooseHome() { start(Intent(Settings.ACTION_HOME_SETTINGS)) }

        @JavascriptInterface
        fun isDefault(): Boolean {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
            return ri?.activityInfo?.packageName == packageName
        }

        @JavascriptInterface
        fun launch(pkg: String, cls: String) {
            start(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(ComponentName(pkg, cls)))
        }

        @JavascriptInterface
        fun kind(k: String) {
            val i = when (k) {
                "phone" -> Intent(Intent.ACTION_DIAL)
                "cam" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                "msg" -> cat(Intent.CATEGORY_APP_MESSAGING)
                "web" -> cat(Intent.CATEGORY_APP_BROWSER)
                "gallery" -> cat(Intent.CATEGORY_APP_GALLERY)
                "maps" -> cat(Intent.CATEGORY_APP_MAPS)
                "music" -> cat(Intent.CATEGORY_APP_MUSIC)
                "cal" -> cat(Intent.CATEGORY_APP_CALENDAR)
                else -> null
            }
            if (i != null) start(i)
        }
    }
}
