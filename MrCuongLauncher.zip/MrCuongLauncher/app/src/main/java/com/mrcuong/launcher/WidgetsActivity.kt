package com.mrcuong.launcher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/**
 * Trang tiện ích: lưu trữ widget Android thật qua AppWidgetHost.
 * Thêm: chọn provider > cấp quyền bind (nếu cần) > màn hình cấu hình (nếu có) > hiển thị.
 * Xóa: nút ✕ có xác nhận. Danh sách widget lưu trong SharedPreferences "widgets".
 */
class WidgetsActivity : AppCompatActivity() {

    private lateinit var host: AppWidgetHost
    private lateinit var mgr: AppWidgetManager
    private lateinit var list: LinearLayout
    private lateinit var prefs: SharedPreferences
    private val ids = ArrayList<Int>()
    private var pendingId = -1
    private var density = 1f
    private var emptyView: TextView? = null
    private var pickMode = false

    companion object {
        const val HOST_ID = 1024
        const val REQ_BIND = 7001
        const val REQ_CONFIG = 7002
        const val MAX_WIDGETS = 12
        private const val TAG = "Widgets"
    }

    private fun dp(v: Int): Int = (v * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        density = resources.displayMetrics.density
        prefs = getSharedPreferences("widgets", Context.MODE_PRIVATE)
        mgr = AppWidgetManager.getInstance(this)
        host = AppWidgetHost(applicationContext, HOST_ID)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#0A0F2E"))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(16), dp(12), dp(16), dp(12))
        val title = TextView(this)
        title.text = "Tiện ích"
        title.setTextColor(Color.WHITE)
        title.textSize = 22f
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val add = TextView(this)
        add.text = "+ Thêm"
        add.setTextColor(Color.parseColor("#CFCAFF"))
        add.textSize = 16f
        add.setPadding(dp(16), dp(10), dp(16), dp(10))
        add.contentDescription = "Thêm tiện ích"
        add.setOnClickListener { pickWidget() }
        header.addView(add)

        val scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(16), 0, dp(16), dp(24))
        scroll.addView(list)

        col.addView(header)
        col.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(col)
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, ins ->
            val s = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, s.top, 0, s.bottom)
            ins
        }
        pickMode = intent.getBooleanExtra("pick", false)
        if (pickMode) {
            // Chế độ chọn: chỉ chọn/bind/cấu hình widget rồi trả id về MainActivity
            title.text = "Chọn tiện ích"
            add.visibility = View.GONE
            root.post { pickWidget() }
        } else {
            loadWidgets()
        }
    }

    override fun onStart() {
        super.onStart()
        try { host.startListening() } catch (e: Exception) { Log.w(TAG, "startListening lỗi", e) }
    }

    override fun onStop() {
        super.onStop()
        try { host.stopListening() } catch (e: Exception) { Log.w(TAG, "stopListening lỗi", e) }
    }

    private fun saveIds() { prefs.edit().putString("ids", ids.joinToString(",")).apply() }

    private fun loadWidgets() {
        ids.clear()
        (prefs.getString("ids", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }.forEach { ids.add(it) }
        list.removeAllViews()
        emptyView = null
        val dead = ArrayList<Int>()
        for (id in ids) { if (!addWidgetView(id)) dead.add(id) }
        if (dead.isNotEmpty()) {   // provider đã bị gỡ hoặc widget lỗi
            for (id in dead) {
                try { host.deleteAppWidgetId(id) } catch (e: Exception) { Log.w(TAG, "xóa id lỗi", e) }
                ids.remove(id)
            }
            saveIds()
        }
        if (ids.isEmpty()) showEmpty()
    }

    private fun showEmpty() {
        val t = TextView(this)
        t.text = "Chưa có tiện ích.\nBấm \"+ Thêm\" để chọn tiện ích của các ứng dụng đã cài."
        t.setTextColor(Color.parseColor("#CFCAFF"))
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(16), dp(80), dp(16), dp(16))
        list.addView(t)
        emptyView = t
    }

    private fun addWidgetView(id: Int): Boolean {
        val info = mgr.getAppWidgetInfo(id) ?: return false
        return try {
            val hv = host.createView(applicationContext, id, info)
            val h = minOf(maxOf(info.minHeight, dp(110)), dp(420))
            val card = FrameLayout(this)
            val bg = GradientDrawable()
            bg.cornerRadius = dp(24).toFloat()
            bg.setColor(Color.argb(60, 255, 255, 255))
            bg.setStroke(maxOf(1, dp(1)), Color.argb(90, 255, 255, 255))
            card.background = bg
            card.clipToOutline = true
            card.outlineProvider = ViewOutlineProvider.BACKGROUND
            card.addView(hv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

            val close = TextView(this)
            close.text = "✕"
            close.setTextColor(Color.WHITE)
            close.gravity = Gravity.CENTER
            val cbg = GradientDrawable()
            cbg.shape = GradientDrawable.OVAL
            cbg.setColor(Color.argb(130, 0, 0, 0))
            close.background = cbg
            close.contentDescription = "Xóa tiện ích"
            close.setOnClickListener { confirmRemove(id) }
            val clp = FrameLayout.LayoutParams(dp(36), dp(36), Gravity.END or Gravity.TOP)
            clp.setMargins(0, dp(6), dp(6), 0)
            card.addView(close, clp)

            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
            lp.bottomMargin = dp(12)
            card.tag = id
            list.addView(card, lp)
            card.post {
                try {
                    val w = (card.width / density).toInt()
                    val hh = (card.height / density).toInt()
                    hv.updateAppWidgetSize(Bundle(), w, hh, w, hh)
                } catch (e: Exception) { Log.w(TAG, "updateAppWidgetSize lỗi", e) }
            }
            true
        } catch (e: Exception) {
            Log.w(TAG, "Không tạo được widget $id", e)
            false
        }
    }

    private fun providerLabel(p: AppWidgetProviderInfo): String {
        val name = try { p.loadLabel(packageManager) ?: "" } catch (e: Exception) { "" }
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(p.provider.packageName, 0)).toString()
        } catch (e: Exception) { p.provider.packageName }
        return if (name.isEmpty()) app else "$app — $name"
    }

    private fun pickWidget() {
        if (!pickMode && ids.size >= MAX_WIDGETS) {
            Toast.makeText(this, "Tối đa $MAX_WIDGETS tiện ích", Toast.LENGTH_SHORT).show()
            return
        }
        val providers = try {
            mgr.installedProviders
                .filter { (it.widgetCategory and AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN) != 0 }
                .map { it to providerLabel(it) }
                .sortedBy { it.second.lowercase() }
        } catch (e: Exception) {
            Log.w(TAG, "Không đọc được danh sách widget", e)
            emptyList()
        }
        if (providers.isEmpty()) {
            Toast.makeText(this, "Thiết bị không có tiện ích khả dụng", Toast.LENGTH_SHORT).show()
            if (pickMode) finish()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Chọn tiện ích")
            .setItems(providers.map { it.second }.toTypedArray()) { _, i -> startAdd(providers[i].first) }
            .setNegativeButton("Hủy") { _, _ -> if (pickMode) finish() }
            .setOnCancelListener { if (pickMode) finish() }
            .show()
    }

    private fun startAdd(info: AppWidgetProviderInfo) {
        val id = try { host.allocateAppWidgetId() } catch (e: Exception) { -1 }
        if (id < 0) {
            Toast.makeText(this, "Không tạo được tiện ích", Toast.LENGTH_SHORT).show()
            if (pickMode) finish()
            return
        }
        pendingId = id
        if (mgr.bindAppWidgetIdIfAllowed(id, info.provider)) {
            finishAdd(id, info)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) {
                Log.w(TAG, "Không mở được màn hình cấp quyền widget", e)
                cancelPending(id)
            }
        }
    }

    private fun finishAdd(id: Int, info: AppWidgetProviderInfo) {
        if (info.configure != null) {
            try {
                host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
            } catch (e: Exception) {
                Log.w(TAG, "Không mở được màn hình cấu hình widget", e)
                commit(id)
            }
        } else {
            commit(id)
        }
    }

    private fun commit(id: Int) {
        pendingId = -1
        if (pickMode) {
            setResult(Activity.RESULT_OK, Intent().putExtra("id", id))
            finish()
            return
        }
        ids.add(id)
        saveIds()
        emptyView?.let { list.removeView(it); emptyView = null }
        if (!addWidgetView(id)) {
            try { host.deleteAppWidgetId(id) } catch (e: Exception) { Log.w(TAG, "xóa id lỗi", e) }
            ids.remove(id)
            saveIds()
            Toast.makeText(this, "Tiện ích này không hiển thị được", Toast.LENGTH_SHORT).show()
            if (ids.isEmpty()) showEmpty()
        }
    }

    private fun cancelPending(id: Int) {
        pendingId = -1
        try { host.deleteAppWidgetId(id) } catch (e: Exception) { Log.w(TAG, "xóa id lỗi", e) }
        if (pickMode) {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingId) ?: pendingId
        if (id < 0) return
        when (requestCode) {
            REQ_BIND -> {
                val info = if (resultCode == Activity.RESULT_OK) mgr.getAppWidgetInfo(id) else null
                if (info != null) finishAdd(id, info) else cancelPending(id)
            }
            REQ_CONFIG -> if (resultCode == Activity.RESULT_OK) commit(id) else cancelPending(id)
        }
    }

    private fun confirmRemove(id: Int) {
        AlertDialog.Builder(this)
            .setTitle("Xóa tiện ích?")
            .setMessage("Chỉ xóa khỏi trang tiện ích, không gỡ ứng dụng.")
            .setPositiveButton("Xóa") { _, _ -> removeWidget(id) }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun removeWidget(id: Int) {
        for (i in 0 until list.childCount) {
            if (list.getChildAt(i).tag == id) { list.removeViewAt(i); break }
        }
        try { host.deleteAppWidgetId(id) } catch (e: Exception) { Log.w(TAG, "xóa id lỗi", e) }
        ids.remove(id)
        saveIds()
        if (ids.isEmpty()) showEmpty()
    }
}
