package com.mrcuong.launcher

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import androidx.annotation.RequiresApi

/**
 * Dịch vụ trợ năng tối giản, CHỈ dùng để khóa màn hình khi người dùng nhấn đúp màn hình chính.
 * Không đọc nội dung màn hình (canRetrieveWindowContent=false), không đăng ký nhận sự kiện,
 * không thu thập hay gửi dữ liệu. Cần Android 9 (API 28) trở lên.
 */
class LockService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: LockService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* không xử lý sự kiện nào */ }

    override fun onInterrupt() { /* không có phản hồi đang chạy */ }

    @RequiresApi(Build.VERSION_CODES.P)
    fun lockNow(): Boolean = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
}
