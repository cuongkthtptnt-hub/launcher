Kiểm thử giao diện launcher (Playwright + Chromium, bridge Android giả lập).
Chạy: python3 launcher_ui_test.py  (cần `pip install playwright` và `playwright install chromium`; sửa đường dẫn `url` trỏ tới app/src/main/assets/index.html).
Kết quả ghi nhận khi phát hành 1.1: 36/36 đạt, không có lỗi JavaScript. Phần Kotlin CHƯA được biên dịch hay chạy trên thiết bị.
launcher_source_template.html là mã nguồn dễ đọc của lớp giao diện (ảnh được thay bằng dấu __IMG__, __DEP__, __PT__).
