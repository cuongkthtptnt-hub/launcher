# Báo cáo nghiệm thu – Mr.Cường Launcher 1.4

**Giới hạn kiểm thử (quan trọng):** môi trường làm việc không có Android SDK/Gradle/Kotlin nên **chưa biên dịch APK, chưa chạy trên emulator hay thiết bị thật**. Lớp giao diện (HTML/JS) được kiểm thử tự động trên Chromium với bridge Android giả lập: **92/92 ca đạt, 0 lỗi JS** (`tests/launcher_ui_test.py`). Mã Kotlin chỉ được rà soát bằng mắt và kiểm tra cân bằng ngoặc. Các mục có phần Kotlin vì vậy ghi "Một phần" cho tới khi chạy thử trên máy thật.

## Kiến trúc
`MainActivity` (WebView + **lớp widget gốc phủ lên WebView**, cảm biến, bridge JS↔Kotlin, icon pack, hình nền) + `WidgetsActivity` (trang tiện ích riêng và **bộ chọn widget** cho màn hình chính) + `assets/index.html` (giao diện, trạng thái, cử chỉ). Cấu hình JSON có phiên bản, lưu SharedPreferences, được làm sạch khi đọc.

## Thay đổi đợt 3
| STT | Nhóm | Tính năng | Trạng thái | Tệp | Kiểm thử | Tồn tại / Hướng xử lý |
|---|---|---|---|---|---|---|
| 1 | Kéo thả | **Kéo ứng dụng từ ngăn kéo thả lên màn hình chính** (ngăn kéo thu lại, thả vào ô trống/dock; ô đã có hoặc ứng dụng trùng bị từ chối và mở lại ngăn kéo; kéo sát mép phải ở trang cuối tự tạo trang mới) | Hoàn thành (chuột giả lập) | index.html | T30a–d | Cảm ứng thật chưa thử |
| 2 | Kéo thả | Kéo đổi chỗ/xóa shortcut trên màn hình chính (đợt 2, giữ nguyên, hoạt động cùng widget) | Hoàn thành | index.html | T6, T7 | — |
| 3 | Widget | **Thêm widget thật lên màn hình chính**: chọn cỡ theo ô lưới (nhỏ ½×1, vừa toàn ngang×1, lớn toàn ngang×2) > chọn provider > bind/cấu hình > đặt vào ô trống (ưu tiên trang hiện tại, hết chỗ thì trang khác) | Một phần | index.html, MainActivity.kt, WidgetsActivity.kt | JS: T31a–q; Kotlin chưa chạy | Chưa kéo thả được chính widget |
| 4 | Widget | Hiển thị widget gốc đúng ô lưới (lớp AppWidgetHost phủ trên WebView, đồng bộ vị trí), tự ẩn khi mở ngăn kéo/menu/hộp thoại/đang kéo/đang chuyển trang | Một phần | index.html, MainActivity.kt | JS: T31c–f; Kotlin chưa chạy | Cần kiểm tra độ khớp và nhấp nháy trên máy thật |
| 5 | Widget | Đổi cỡ, chuyển trang, xóa (có xác nhận); menu mở bằng nhấn giữ widget hoặc từ Cài đặt > "Tiện ích trên màn hình chính" (dự phòng khi widget chặn nhấn giữ) | Một phần | index.html, MainActivity.kt | T31g–j, T31q | Nhấn giữ trực tiếp có thể bị widget chặn ở một số loại |
| 6 | Widget | Widget lỗi/provider bị gỡ tự được dọn; id không dùng được giải phóng; đổi lưới luôn giữ widget hợp lệ; dữ liệu widget hỏng/chồng lấn bị loại | Hoàn thành (lớp JS) | index.html, MainActivity.kt | T31m–p | Phần giải phóng id chưa chạy thật |
| 7 | Icon | **Icon pack chuẩn ADW/Nova**: liệt kê pack đã cài, đọc appfilter.xml, áp dụng cho ngăn kéo và màn hình chính, lưu lựa chọn | Một phần | MainActivity.kt, AndroidManifest.xml, index.html | JS: T27a–b; Kotlin chưa chạy | Chưa dùng iconback/mask; chỉ ánh xạ theo component |
| 8 | Icon | **Đổi biểu tượng từng shortcut** (24 biểu tượng kính + "Mặc định"), giữ nguyên khả năng mở đúng ứng dụng | Hoàn thành | index.html | T24a–c, T25a–b | Chưa chọn ảnh tự do từ thư viện |
| 9 | Giao diện | **Chế độ sáng/tối/theo hệ thống** cho ngăn kéo, cài đặt, menu, hộp thoại | Hoàn thành | index.html | T26a–c, T29 | Màn hình chính giữ nền tối để hợp hình nền |
| 10 | Trợ năng | Trang/chấm trang có role + aria-label, điều khiển chấm trang bằng bàn phím, mọi icon có nhãn | Một phần | index.html | T28a–b | Chưa thử TalkBack thật; kéo thả chưa có thao tác thay thế cho TalkBack |

## Tình trạng toàn bộ chức năng (gộp đợt 1–3)
Hoàn thành ở lớp giao diện (đã có test JS): nhiều trang + lưới cấu hình, vuốt ngang 3D/phẳng, kéo thả (trong màn hình chính + từ ngăn kéo), ngăn kéo (tìm không dấu, sắp xếp, lưới/danh sách, ẩn app), menu nhấn giữ, cử chỉ, cài đặt, sao lưu/nhập, đặt lại, đổi tên/biểu tượng/kiểu icon, sáng/tối, giảm chuyển động, hiệu năng dựng 400 app.
Một phần (cần chạy máy thật): widget (trang riêng + màn hình chính), hình nền tùy chỉnh, icon pack, đăng ký HOME, SharedPreferences, package receiver, trợ năng.
Chưa làm: kéo thả chính widget; ảnh tự chọn làm icon; test đơn vị Kotlin; đo FPS/jank; TalkBack thật.

## Giới hạn do Android
Launcher không thay được gesture/phím điều hướng hệ thống; không khóa màn hình bằng nhấn đúp; ứng dụng bên thứ ba tự vẽ giao diện nên không áp nền kính mờ. Widget phải do AppWidgetHost gốc hiển thị (nên nằm ở lớp phủ trên WebView, không thể nằm trong WebView).

## Quyền
INTERNET (font), REQUEST_DELETE_PACKAGES, EXPAND_STATUS_BAR; khai báo `<queries>` cho launcher/icon pack. Không dùng QUERY_ALL_PACKAGES.

## Việc ưu tiên tiếp theo
1) Build và chạy thử trên máy thật, gửi lại lỗi/hiện tượng; 2) kéo thả widget; 3) icon từ ảnh/gallery; 4) test đơn vị Kotlin và đo jank; 5) TalkBack.

## Bổ sung bản 1.4: nhấn đúp khóa màn hình
| STT | Nhóm | Tính năng | Trạng thái | Tệp | Kiểm thử | Tồn tại / Hướng xử lý |
|---|---|---|---|---|---|---|
| 1 | Cử chỉ | **Nhấn đúp vùng trống của màn hình chính để khóa màn hình** (tùy chọn, mặc định TẮT; không kích hoạt khi chạm vào icon/thẻ/dock, khi hai lần chạm quá chậm hoặc quá xa) | Hoàn thành (lớp JS) | index.html | T32a–k | — |
| 2 | Cử chỉ | **Dịch vụ khóa màn hình** (`LockService`, Dịch vụ trợ năng tối giản: không đọc nội dung, không nhận sự kiện, không thu thập dữ liệu), kiểm tra trạng thái, nút thử khóa, mở cài đặt trợ năng | Một phần | LockService.kt, lock_service.xml, strings.xml, AndroidManifest.xml, MainActivity.kt | JS: T32g–j; Kotlin chưa chạy | Cần Android 9+ và người dùng tự bật dịch vụ; chưa thử trên máy thật |
| 3 | Quyền | Hộp thoại giải thích trước khi chuyển sang cài đặt trợ năng (nêu rõ mục đích duy nhất là khóa màn hình) | Hoàn thành | index.html | T32g | Google Play có chính sách riêng cho dịch vụ trợ năng |

**Giới hạn thực tế:** Android không có API thường để launcher tự khóa máy. Cách duy nhất không cần quyền quản trị thiết bị là Dịch vụ trợ năng (`GLOBAL_ACTION_LOCK_SCREEN`, Android 9+). Vân tay/khuôn mặt vẫn dùng bình thường sau khi khóa. Có thể thay bằng Quản trị thiết bị (`lockNow`) nhưng cách đó khiến việc gỡ launcher phải tắt quyền quản trị trước, nên chưa dùng.
