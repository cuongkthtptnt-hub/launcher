# Mr.Cường Launcher
1. Cài Android Studio mới nhất > File > Open > chọn thư mục MrCuongLauncher, đợi Gradle sync (cần internet lần đầu).
2. Build > Build APK(s). File: app/build/outputs/apk/debug/app-debug.apk
3. Chép sang điện thoại, cho phép cài từ nguồn không xác định, cài đặt.
4. Bấm Home > chọn "Mr.Cường Launcher" > "Luôn luôn".
Ghi chú: chữ ký Great Vibes tải qua internet (máy offline sẽ dùng kiểu chữ viết tay mặc định).
Thay ảnh xe/chân dung: sửa app/src/main/assets/index.html (ảnh nhúng dạng base64).

## Build APK không cần Android Studio (GitHub Actions)
1. Tạo tài khoản GitHub, tạo repository mới (nên để Private).
2. Tải toàn bộ nội dung thư mục này lên repository (nhớ cả thư mục .github).
3. Vào tab Actions > "Build APK" > Run workflow. Đợi khoảng 5 phút.
4. Tải APK ở mục Releases (hoặc Artifacts của lần chạy), chép/cài vào điện thoại.

## Phiên bản 1.4 (xem NghiemThu.md)
Xem NghiemThu.md để biết tính năng đã làm, đã kiểm thử và chưa làm.
